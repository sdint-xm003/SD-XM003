package com.sd.xm003.util;//package com.sd.xm003.util;
//
//import tk.mybatis.mapper.common.Mapper;
//import tk.mybatis.mapper.common.MySqlMapper;
//
///**
// * Created by KF03 on 2017/7/22.
// */
//public interface MyMapper<T> extends Mapper<T>,MySqlMapper<T> {
//    //TODO
//    //FIXME 特别注意，该接口不能被扫描到，否则会出错
//}
