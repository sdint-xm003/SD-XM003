package com.sd.xm003.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.io.ClassPathResource;

/**
 * Created by KF03 on 2017/7/31.
 */
@Configuration
@PropertySource({
        "classpath:application.properties"
})
public class InitConfig {
    @Bean
    public static PropertySourcesPlaceholderConfigurer propertySourcesPlaceholderConfigurer() {
        /**
         * PropertyPlaceholderConfigurer类就是bean factory post-processor的一种，它的作用是一个资源属性的配置器，能够将BeanFactory的里定义的内容放在一个以.propertis后缀的文件中。
         */
        PropertySourcesPlaceholderConfigurer propertySourcesPlaceholderConfigurer = new PropertySourcesPlaceholderConfigurer();
        propertySourcesPlaceholderConfigurer.setLocations(new ClassPathResource("/application.properties"));
        return propertySourcesPlaceholderConfigurer;
    }
}
